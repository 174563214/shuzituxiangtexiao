function varargout = magic(varargin)
% MAGIC M-file for magic.fig
%      MAGIC, by itself, creates a new MAGIC or raises the existing
%      singleton*.
%
%      H = MAGIC returns the handle to a new MAGIC or the handle to
%      the existing singleton*.
%
%      MAGIC('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in MAGIC.M with the given input arguments.
%
%      MAGIC('Property','Value',...) creates a new MAGIC or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before magic_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to magic_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% Edit the above text to modify the response to help magic

% Last Modified by GUIDE v2.5 22-Oct-2021 20:57:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
    'gui_Singleton',  gui_Singleton, ...
    'gui_OpeningFcn', @magic_OpeningFcn, ...
    'gui_OutputFcn',  @magic_OutputFcn, ...
    'gui_LayoutFcn',  [] , ...
    'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before magic is made visible.
function magic_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to magic (see VARARGIN)

% Choose default command line output for magic
handles.output = hObject;
set(gcf,'name','��ϵ΢�� matlab1998  ');


% UIWAIT makes magic wait for user response (see UIRESUME)
% uiwait(handles.magic);


%image data
setappdata(0,'origin_image',[]);
setappdata(0,'process_image',[]);
setappdata(0, 'after_process_image', []);

%set for axes
setappdata(0,'magic_axes', handles.magic_axes);

%set for file
handles.filename = '';
handles.path = '';


%set for gray process
handles.Maximum = 1;
handles.Average = 2;
handles.Weight_Average = 4;


%set for channel extract process
handles.channel_red = 1;
handles.channel_green = 2;
handles.channel_blue = 3;


%set for channel filter process
handles.channel_filter_red = 1;
handles.channel_filter_green = 2;
handles.channel_filter_blue = 4;
handles.channel_filter_cyan = 6;
handles.channel_filter_megenta = 5;
handles.channel_filter_yellow = 3;
handles.channel_filter_white = 7 ;


%set for direction emboss process
handles.north = 1;
handles.north_east = 2;
handles.east = 3;
handles.south_east = 4;
handles.south = 5;
handles.south_west = 6;
handles.west = 7;
handles.north_west = 8;


addpath(genpath(pwd));


% Update handles structure
guidata(hObject, handles);








input = imread('channel.jpg');
input = myIm2double(input);
setappdata(0,'origin_image',input);
setappdata(0,'process_image',input);
guidata(hObject, handles);
%%show_origin_image;






% --- Outputs from this function are returned to the command line.
function varargout = magic_OutputFcn(hObject, eventdata, handles)
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --------------------------------------------------------------------
function open_menu_Callback(hObject, eventdata, handles)
% hObject    handle to open_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
[filename,path] = uigetfile({'*.jpg';'*.bmp';'*.tif';'*.*'},'File Selector');
if ~isequal(filename,0)
    handles.filename = filename;
    handles.path = path;
    input = imread([path filename]);
    input = myIm2double(input);
    setappdata(0,'origin_image',input);
    setappdata(0,'process_image',input);
    guidata(hObject, handles);
    show_origin_image;
end
msgbox('Դ����ϵ΢�� matlab1998')

% --------------------------------------------------------------------
function save_menu_Callback(hObject, eventdata, handles)
% hObject    handle to save_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0,'process_image');
disp([handles.path handles.filename]);
imwrite(image, [handles.path handles.filename]);

% --------------------------------------------------------------------
function saveas_menu_Callback(hObject, eventdata, handles)
% hObject    handle to saveas_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0,'process_image');
[filename, pathname] = uiputfile({'*.bmp';'*.jpg';'*.tif';'*.*'}, ...
    'Save as');

if ~isequal(filename,0)
    imwrite(image, [pathname filename]);
end

% --------------------------------------------------------------------
function file_menu_Callback(hObject, eventdata, handles)
% hObject    handle to file_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function picture_menu_Callback(hObject, eventdata, handles)
% hObject    handle to picture_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function reset_menu_Callback(hObject, eventdata, handles)
% hObject    handle to reset_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
%image = getappdata(0, 'origin_image');
%setappdata(0, 'process_image', image);
%show_origin_image;


% --------------------------------------------------------------------
function color_balance_Callback(hObject, eventdata, handles)
% hObject    handle to color_balance (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%set for color balance process


% --------------------------------------------------------------------
function adjust_menu_Callback(hObject, eventdata, handles)
% hObject    handle to adjust_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function brightness_Callback(hObject, eventdata, handles)
% hObject    handle to brightness (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function contrast_Callback(hObject, eventdata, handles)
% hObject    handle to contrast (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
msgbox('�����ƣ���ϵ΢�� matlab1998')



% --------------------------------------------------------------------
function gray_average_Callback(hObject, eventdata, handles)
% hObject    handle to gray_average (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = gray_process(image, handles.Average);
setappdata(0, 'process_image',image);
show_origin_image;

% --------------------------------------------------------------------
function gray_weight_average_Callback(hObject, eventdata, handles)
% hObject    handle to gray_weight_average (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = gray_process(image, handles.Weight_Average);
setappdata(0, 'process_image',image);
show_origin_image;

% --------------------------------------------------------------------
function gray_maximum_Callback(hObject, eventdata, handles)
% hObject    handle to gray_maximum (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = gray_process(image, handles.Maximum);
setappdata(0, 'process_image',image);
show_origin_image;

% --------------------------------------------------------------------
function gray_menu_Callback(hObject, eventdata, handles)
% hObject    handle to gray_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function global_threshold_Callback(hObject, eventdata, handles)
% hObject    handle to global_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = global_threshold_process(image);
setappdata(0, 'process_image',image);
show_origin_image;

% --------------------------------------------------------------------
function local_threshold_Callback(hObject, eventdata, handles)
% hObject    handle to local_threshold (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
setappdata(0, 'local_threshold_slider', 0);
setappdata(0, 'update_local_threshold_axes', @update_local_threshold_axes);
threshold_dlg;

% --------------------------------------------------------------------
function threshold_menu_Callback(hObject, eventdata, handles)
% hObject    handle to threshold_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function negative_Callback(hObject, eventdata, handles)
% hObject    handle to negative (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function pseudo_color_curve_Callback(hObject, eventdata, handles)
% hObject    handle to pseudo_color_curve (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function pseudo_color_table_Callback(hObject, eventdata, handles)
% hObject    handle to pseudo_color_table (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --------------------------------------------------------------------
function pseudo_color_menu_Callback(hObject, eventdata, handles)
% hObject    handle to pseudo_color_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function channel_rotate_Callback(hObject, eventdata, handles)
% hObject    handle to channel_rotate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = rotate_channel_process(image);
setappdata(0, 'process_image',image);
show_origin_image;

% --------------------------------------------------------------------
function channel_extract_Callback(hObject, eventdata, handles)
% hObject    handle to channel_extract (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function channel_filter_Callback(hObject, eventdata, handles)
% hObject    handle to channel_filter (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function channel_menu_Callback(hObject, eventdata, handles)
% hObject    handle to channel_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function channel_extract_red_Callback(hObject, eventdata, handles)
% hObject    handle to channel_extract_red (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = extract_process(image, handles.channel_red);
setappdata(0, 'process_image',image);
show_origin_image;

% --------------------------------------------------------------------
function channle_extract_green_Callback(hObject, eventdata, handles)
% hObject    handle to channle_extract_green (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = extract_process(image, handles.channel_green);
setappdata(0, 'process_image',image);
show_origin_image;

% --------------------------------------------------------------------
function channel_extract_blue_Callback(hObject, eventdata, handles)
% hObject    handle to channel_extract_blue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = extract_process(image, handles.channel_blue);
setappdata(0, 'process_image',image);
show_origin_image;



% --------------------------------------------------------------------
function channel_filter_red_Callback(hObject, eventdata, handles)
% hObject    handle to channel_filter_red (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = filter_channel_process(image, handles.channel_filter_red);
setappdata(0, 'process_image',image);
show_origin_image;

% --------------------------------------------------------------------
function channel_filter_green_Callback(hObject, eventdata, handles)
% hObject    handle to channel_filter_green (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = filter_channel_process(image, handles.channel_filter_green);
setappdata(0, 'process_image',image);
show_origin_image;

% --------------------------------------------------------------------
function channel_filter_blue_Callback(hObject, eventdata, handles)
% hObject    handle to channel_filter_blue (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = filter_channel_process(image, handles.channel_filter_blue);
setappdata(0, 'process_image',image);
show_origin_image;

% --------------------------------------------------------------------
function channel_filter_cyan_Callback(hObject, eventdata, handles)
% hObject    handle to channel_filter_cyan (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = filter_channel_process(image, handles.channel_filter_cyan);
setappdata(0, 'process_image',image);
show_origin_image;

% --------------------------------------------------------------------
function channel_filter_megenta_Callback(hObject, eventdata, handles)
% hObject    handle to channel_filter_megenta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = filter_channel_process(image, handles.channel_filter_megenta);
setappdata(0, 'process_image',image);
show_origin_image;

% --------------------------------------------------------------------
function channel_filter_yellow_Callback(hObject, eventdata, handles)
% hObject    handle to channel_filter_yellow (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');
image = filter_channel_process(image, handles.channel_filter_yellow);
setappdata(0, 'process_image',image);
show_origin_image;



% --------------------------------------------------------------------
function brightness_mapping_Callback(hObject, eventdata, handles)
% hObject    handle to brightness_mapping (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --------------------------------------------------------------------
function image_traslate_Callback(hObject, eventdata, handles)
% hObject    handle to image_traslate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
translate_dlg;



% --------------------------------------------------------------------
function rotate_random_angle_Callback(hObject, eventdata, handles)
% hObject    handle to rotate_random_angle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function rotate_menu_Callback(hObject, eventdata, handles)
% hObject    handle to rotate_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function rotate_horz_Callback(hObject, eventdata, handles)
% hObject    handle to rotate_horz (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%disp('process');

% --------------------------------------------------------------------
function rotate_vertical_Callback(hObject, eventdata, handles)
% hObject    handle to rotate_vertical (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --------------------------------------------------------------------
function transpose_Callback(hObject, eventdata, handles)
% hObject    handle to transpose (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --------------------------------------------------------------------
function blur_smooth_Callback(hObject, eventdata, handles)
% hObject    handle to blur_smooth (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function blur_menu_Callback(hObject, eventdata, handles)
% hObject    handle to blur_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function special_filter_menu_Callback(hObject, eventdata, handles)
% hObject    handle to special_filter_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)





% --------------------------------------------------------------------
function blur_gauss_Callback(hObject, eventdata, handles)
% hObject    handle to blur_gauss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function blur_motion_Callback(hObject, eventdata, handles)
% hObject    handle to blur_motion (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)



% --------------------------------------------------------------------
function sharpen_normal_Callback(hObject, eventdata, handles)
% hObject    handle to sharpen_normal (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function sharpen_more_Callback(hObject, eventdata, handles)
% hObject    handle to sharpen_more (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function sharpen_free_Callback(hObject, eventdata, handles)
% hObject    handle to sharpen_free (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function sharpen_menu_Callback(hObject, eventdata, handles)
% hObject    handle to sharpen_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function unsharp_mask_Callback(hObject, eventdata, handles)
% hObject    handle to unsharp_mask (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function regularity_emboss_Callback(hObject, eventdata, handles)
% hObject    handle to regularity_emboss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function direction_emboss_Callback(hObject, eventdata, handles)
% hObject    handle to direction_emboss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function gray_emboss_Callback(hObject, eventdata, handles)
% hObject    handle to gray_emboss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function color_emboss_Callback(hObject, eventdata, handles)
% hObject    handle to color_emboss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function emboss_menu_Callback(hObject, eventdata, handles)
% hObject    handle to emboss_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function direction_emboss_north_Callback(hObject, eventdata, handles)
% hObject    handle to direction_emboss_north (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');

set(handles.magic, 'Interruptible', 'off');
set(handles.magic, 'Pointer', 'watch');

image = direction_emboss_process(image, handles.north);
setappdata(0, 'process_image', image);
show_origin_image;
set(handles.magic,'Pointer', 'arrow');
set(handles.magic, 'Interruptible', 'on');

% --------------------------------------------------------------------
function direction_emboss_north_east_Callback(hObject, eventdata, handles)
% hObject    handle to direction_emboss_north_east (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');

set(handles.magic, 'Interruptible', 'off');
set(handles.magic, 'Pointer', 'watch');

image = direction_emboss_process(image, handles.north_west);
setappdata(0, 'process_image', image);
show_origin_image;
set(handles.magic,'Pointer', 'arrow');
set(handles.magic, 'Interruptible', 'on');

% --------------------------------------------------------------------
function direction_emboss_east_Callback(hObject, eventdata, handles)
% hObject    handle to direction_emboss_east (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');

set(handles.magic, 'Interruptible', 'off');
set(handles.magic, 'Pointer', 'watch');

image = direction_emboss_process(image, handles.east);
setappdata(0, 'process_image', image);
show_origin_image;
set(handles.magic,'Pointer', 'arrow');
set(handles.magic, 'Interruptible', 'on');

% --------------------------------------------------------------------
function direction_emboss_south_east_Callback(hObject, eventdata, handles)
% hObject    handle to direction_emboss_south_east (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');

set(handles.magic, 'Interruptible', 'off');
set(handles.magic, 'Pointer', 'watch');

image = direction_emboss_process(image, handles.south_east);
setappdata(0, 'process_image', image);
show_origin_image;
set(handles.magic,'Pointer', 'arrow');
set(handles.magic, 'Interruptible', 'on');

% --------------------------------------------------------------------
function direction_emboss_south_Callback(hObject, eventdata, handles)
% hObject    handle to direction_emboss_south (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');

set(handles.magic, 'Interruptible', 'off');
set(handles.magic, 'Pointer', 'watch');

image = direction_emboss_process(image, handles.south);
setappdata(0, 'process_image', image);
show_origin_image;
set(handles.magic,'Pointer', 'arrow');
set(handles.magic, 'Interruptible', 'on');

% --------------------------------------------------------------------
function direction_emboss_south_west_Callback(hObject, eventdata, handles)
% hObject    handle to direction_emboss_south_west (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');

set(handles.magic, 'Interruptible', 'off');
set(handles.magic, 'Pointer', 'watch');

image = direction_emboss_process(image, handles.south_west);
setappdata(0, 'process_image', image);
show_origin_image;
set(handles.magic,'Pointer', 'arrow');
set(handles.magic, 'Interruptible', 'on');

% --------------------------------------------------------------------
function direction_emboss_west_Callback(hObject, eventdata, handles)
% hObject    handle to direction_emboss_west (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');

set(handles.magic, 'Interruptible', 'off');
set(handles.magic, 'Pointer', 'watch');

image = direction_emboss_process(image, handles.west);
setappdata(0, 'process_image', image);
show_origin_image;
set(handles.magic,'Pointer', 'arrow');
set(handles.magic, 'Interruptible', 'on');

% --------------------------------------------------------------------
function direction_emboss_north_west_Callback(hObject, eventdata, handles)
% hObject    handle to direction_emboss_north_west (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');

set(handles.magic, 'Interruptible', 'off');
set(handles.magic, 'Pointer', 'watch');

image = direction_emboss_process(image, handles.north_west);
setappdata(0, 'process_image', image);
show_origin_image;
set(handles.magic,'Pointer', 'arrow');
set(handles.magic, 'Interruptible', 'on');



% --------------------------------------------------------------------
function noise_add_Callback(hObject, eventdata, handles)
% hObject    handle to noise_add (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
noise_add_dlg;

% --------------------------------------------------------------------
function noise_salt_Callback(hObject, eventdata, handles)
% hObject    handle to noise_salt (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
noise_salt_dlg;

% --------------------------------------------------------------------
function noise_menu_Callback(hObject, eventdata, handles)
% hObject    handle to noise_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function art_paper_cut_Callback(hObject, eventdata, handles)
% hObject    handle to art_paper_cut (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
art_paper_cut_dlg;



% --------------------------------------------------------------------
function art_menu_Callback(hObject, eventdata, handles)
% hObject    handle to art_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function equalize_Callback(hObject, eventdata, handles)
% hObject    handle to equalize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function add_Callback(hObject, eventdata, handles)
% hObject    handle to add (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
add_image_dlg;

% --------------------------------------------------------------------
function math_menu_Callback(hObject, eventdata, handles)
% hObject    handle to math_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function other_menu_Callback(hObject, eventdata, handles)
% hObject    handle to other_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function reset_image_menu_Callback(hObject, eventdata, handles)
% hObject    handle to reset_image_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function sub_Callback(hObject, eventdata, handles)
% hObject    handle to sub (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
sub_image_dlg;



% --------------------------------------------------------------------
function mutiply_Callback(hObject, eventdata, handles)
% hObject    handle to mutiply (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
mutiply_image_dlg;

% --------------------------------------------------------------------
function divide_Callback(hObject, eventdata, handles)
% hObject    handle to divide (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
divide_image_dlg;



% --------------------------------------------------------------------
function average_Callback(hObject, eventdata, handles)
% hObject    handle to average (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
average_image_dlg;

% --------------------------------------------------------------------
function differ_Callback(hObject, eventdata, handles)
% hObject    handle to differ (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
differ_image_dlg;



% --------------------------------------------------------------------
function blur_radia_Callback(hObject, eventdata, handles)
% hObject    handle to blur_radia (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)





% --------------------------------------------------------------------
function pencil_Callback(hObject, eventdata, handles)
% hObject    handle to pencil (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
pencil_dlg;

% --------------------------------------------------------------------
function sketch_Callback(hObject, eventdata, handles)
msgbox('Դ������ϵ΢�� matlab1998')
% hObject    handle to sketch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function comic_Callback(hObject, eventdata, handles)
% hObject    handle to comic (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function aqua_Callback(hObject, eventdata, handles)
% hObject    handle to aqua (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function sepia_Callback(hObject, eventdata, handles)
% hObject    handle to sepia (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% --------------------------------------------------------------------
function colorize_Callback(hObject, eventdata, handles)
% hObject    handle to colorize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function molten_Callback(hObject, eventdata, handles)
% hObject    handle to molten (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function darkness_Callback(hObject, eventdata, handles)
% hObject    handle to darkness (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function subtense_Callback(hObject, eventdata, handles)
% hObject    handle to subtense (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function whim_Callback(hObject, eventdata, handles)
% hObject    handle to whim (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function ice_Callback(hObject, eventdata, handles)
% hObject    handle to ice (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function pinch_Callback(hObject, eventdata, handles)
% hObject    handle to pinch (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

pinch_dlg;
% --------------------------------------------------------------------
function spherize_Callback(hObject, eventdata, handles)
% hObject    handle to spherize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

image = getappdata(0, 'process_image');

set(handles.magic, 'Interruptible', 'off');
set(handles.magic, 'Pointer', 'watch');

image = spherize_process(image);

setappdata(0, 'process_image', image);
show_origin_image;
set(handles.magic,'Pointer', 'arrow');
set(handles.magic, 'Interruptible', 'on');
% --------------------------------------------------------------------
function swirl_Callback(hObject, eventdata, handles)
% hObject    handle to swirl (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
swril_dlg;
% --------------------------------------------------------------------
function wave_Callback(hObject, eventdata, handles)
% hObject    handle to wave (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

wave_dlg;
% --------------------------------------------------------------------
function moire_fringe_Callback(hObject, eventdata, handles)
% hObject    handle to moire_fringe (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
moire_fringe_dlg;
function distort_Callback(hObject, eventdata, handles)
% hObject    handle to distort (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function diffuse_Callback(hObject, eventdata, handles)
% hObject    handle to diffuse (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
diffuse_dlg;
% --------------------------------------------------------------------
function find_edge_Callback(hObject, eventdata, handles)
% hObject    handle to find_edge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
find_edge_dlg;

% --------------------------------------------------------------------
function glow_edge_Callback(hObject, eventdata, handles)
% hObject    handle to glow_edge (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

image = getappdata(0, 'process_image');

set(handles.magic, 'Interruptible', 'off');
set(handles.magic, 'Pointer', 'watch');

image = glow_edge_process(image);

setappdata(0, 'process_image', image);
show_origin_image;
set(handles.magic,'Pointer', 'arrow');
set(handles.magic, 'Interruptible', 'on');
% --------------------------------------------------------------------
function lighting_Callback(hObject, eventdata, handles)
% hObject    handle to lighting (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
lighting_dlg;
% --------------------------------------------------------------------
function mosaic_Callback(hObject, eventdata, handles)
% hObject    handle to mosaic (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
mosaic_dlg;

% --------------------------------------------------------------------
function oil_painting_Callback(hObject, eventdata, handles)
% hObject    handle to oil_painting (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


% --------------------------------------------------------------------
function solarize_Callback(hObject, eventdata, handles)
% hObject    handle to solarize (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

image = getappdata(0, 'process_image');

set(handles.magic, 'Interruptible', 'off');
set(handles.magic, 'Pointer', 'watch');

image = solarize_process(image);

setappdata(0, 'process_image', image);
show_origin_image;
set(handles.magic,'Pointer', 'arrow');
set(handles.magic, 'Interruptible', 'on');
% --------------------------------------------------------------------
function Style_menu_Callback(hObject, eventdata, handles)
% hObject    handle to Style_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function inosculate_Callback(hObject, eventdata, handles)
% hObject    handle to inosculate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
inosculate_dlg;

% --------------------------------------------------------------------
function interleaving_Callback(hObject, eventdata, handles)
% hObject    handle to interleaving (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
interleaving_dlg;

% --------------------------------------------------------------------
function red_eye_Callback(hObject, eventdata, handles)
% hObject    handle to red_eye (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

red_eye_dlg;
% --------------------------------------------------------------------
function other_style_menu_Callback(hObject, eventdata, handles)
% hObject    handle to other_style_menu (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)




% --------------------------------------------------------------------
function bigger_Callback(hObject, eventdata, handles)
% hObject    handle to bigger (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');

set(handles.magic, 'Interruptible', 'off');
set(handles.magic, 'Pointer', 'watch');

image = bigger_process(image);

setappdata(0, 'process_image', image);
show_origin_image;
setappdata(0,'origin_image',image);
set(handles.magic,'Pointer', 'arrow');
set(handles.magic, 'Interruptible', 'on');

% --------------------------------------------------------------------
function smaller_Callback(hObject, eventdata, handles)
% hObject    handle to smaller (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
image = getappdata(0, 'process_image');

set(handles.magic, 'Interruptible', 'off');
set(handles.magic, 'Pointer', 'watch');

image = small_process(image);

setappdata(0, 'process_image', image);
show_origin_image;
setappdata(0,'origin_image',image);
set(handles.magic,'Pointer', 'arrow');
set(handles.magic, 'Interruptible', 'on');



% --- Executes during object creation, after setting all properties.
function magic_CreateFcn(hObject, eventdata, handles)
% hObject    handle to magic (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called


% --- Executes on mouse press over figure background, over a disabled or
% --- inactive control, or over an axes background.
function magic_WindowButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to magic (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
